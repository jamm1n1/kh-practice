package com.kh.dimension.practice;

public class Run {

	public static void main(String[] args) {
		
		DimensionPractice a= new DimensionPractice();
		a.practice4();
	}

}
