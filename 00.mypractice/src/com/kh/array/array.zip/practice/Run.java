package com.kh.array.practice;

public class Run {

	public static void main(String[] args) {
		
		ArrayPractice a = new ArrayPractice();
		a.practice5();
		
		}

	}


